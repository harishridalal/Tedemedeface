package com.prateek.offlinefilters

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import com.google.mediapipe.tasks.components.containers.NormalizedLandmark
import kotlin.math.abs

class FaceFilterOverlayView @JvmOverloads constructor(context: Context, attrs: AttributeSet? = null) : View(context, attrs) {
    fun applyFilter(filter: Filter) { selectedFilter = filter; postInvalidateOnAnimation() }
    enum class Filter {
        NONE, DOG, GLASSES, CROWN, HEARTS, CAT, BUNNY, DEVIL, MUSTACHE, BLUSH, ALIEN, FLOWER, STAR, MASK
    }
    @Volatile private var landmarks: List<NormalizedLandmark>? = null
    @Volatile var selectedFilter: Filter = Filter.DOG
        set(value) { field = value; postInvalidateOnAnimation() }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 5f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }

    fun setFilter(filter: Filter) { selectedFilter = filter }
    fun selectedFilterName(): String = selectedFilter.name.lowercase().replaceFirstChar { it.uppercase() }
    fun setActiveFilter(filter: Filter) { selectedFilter = filter }
    fun updateLandmarks(points: List<NormalizedLandmark>?) { landmarks = points; postInvalidateOnAnimation() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val pts = landmarks ?: return
        if (pts.size < 468 || selectedFilter == Filter.NONE) return
        fun p(i: Int): Pair<Float, Float> {
            val lm = pts[i]
            return Pair((1f - lm.x()) * width, lm.y() * height)
        }
        val left = p(234); val right = p(454); val forehead = p(10); val nose = p(1)
        val faceW = abs(right.first - left.first).coerceAtLeast(30f)
        val cx = (left.first + right.first) / 2f
        fun oval(x: Float, y: Float, rx: Float, ry: Float, color: Int) {
            fill.color = color
            canvas.drawOval(x-rx, y-ry, x+rx, y+ry, fill)
        }
        fun triangle(points: List<Pair<Float, Float>>, color: Int) {
            fill.color = color
            val path = Path().apply {
                moveTo(points[0].first, points[0].second)
                for (i in 1 until points.size) lineTo(points[i].first, points[i].second)
                close()
            }
            canvas.drawPath(path, fill)
        }
        when (selectedFilter) {
            Filter.NONE -> Unit
            Filter.DOG -> {
                val earW = faceW * .22f; val earH = faceW * .28f; val earY = forehead.second - earH * .45f
                fill.color = Color.rgb(151, 92, 54)
                val lPath = Path().apply { moveTo(forehead.first-faceW*.28f, earY+earH); quadTo(forehead.first-faceW*.42f, earY-earH*.35f, forehead.first-faceW*.16f, earY+earH*.18f); close() }
                val rPath = Path().apply { moveTo(forehead.first+faceW*.28f, earY+earH); quadTo(forehead.first+faceW*.42f, earY-earH*.35f, forehead.first+faceW*.16f, earY+earH*.18f); close() }
                canvas.drawPath(lPath, fill); canvas.drawPath(rPath, fill)
                oval(nose.first, nose.second+faceW*.035f, faceW*.075f, faceW*.055f, Color.rgb(255,190,190))
                oval(nose.first, nose.second+faceW*.02f, faceW*.025f, faceW*.025f, Color.rgb(65,35,30))
                stroke.color = Color.rgb(65,35,30); stroke.strokeWidth = faceW*.012f
                canvas.drawLine(nose.first, nose.second+faceW*.07f, nose.first, nose.second+faceW*.13f, stroke)
                canvas.drawArc(nose.first-faceW*.07f,nose.second+faceW*.08f,nose.first,nose.second+faceW*.17f,0f,100f,false,stroke)
                canvas.drawArc(nose.first,nose.second+faceW*.08f,nose.first+faceW*.07f,nose.second+faceW*.17f,80f,100f,false,stroke)
            }
            Filter.GLASSES -> drawGlasses(canvas, p(33), p(263), p(168), faceW, Color.rgb(18,18,24), false)
            Filter.CROWN -> {
                val crownW=faceW*.72f; val crownH=faceW*.28f; val y=forehead.second-faceW*.18f
                val crownPath = Path().apply {
                    moveTo(cx-crownW/2, y+crownH)
                    lineTo(cx-crownW/2, y)
                    lineTo(cx-crownW*.22f, y+crownH*.45f)
                    lineTo(cx, y-crownH*.35f)
                    lineTo(cx+crownW*.22f, y+crownH*.45f)
                    lineTo(cx+crownW/2, y)
                    lineTo(cx+crownW/2, y+crownH)
                    close()
                }
                fill.color = Color.rgb(250,190,50)
                canvas.drawPath(crownPath, fill)
                stroke.color = Color.rgb(255,235,150)
                stroke.strokeWidth = faceW*.018f
                canvas.drawPath(crownPath, stroke)
            }
            Filter.HEARTS -> {
                drawHeart(canvas, forehead.first-faceW*.30f, forehead.second-faceW*.23f, faceW*.10f, Color.rgb(255,75,130))
                drawHeart(canvas, forehead.first+faceW*.30f, forehead.second-faceW*.15f, faceW*.08f, Color.rgb(255,120,165))
                drawHeart(canvas, forehead.first, forehead.second-faceW*.34f, faceW*.07f, Color.rgb(255,75,130))
            }
            Filter.CAT -> {
                triangle(listOf(Pair(cx-faceW*.38f,forehead.second+faceW*.06f), Pair(cx-faceW*.32f,forehead.second-faceW*.34f), Pair(cx-faceW*.12f,forehead.second+faceW*.02f)), Color.rgb(65,65,75))
                triangle(listOf(Pair(cx+faceW*.12f,forehead.second+faceW*.02f), Pair(cx+faceW*.32f,forehead.second-faceW*.34f), Pair(cx+faceW*.38f,forehead.second+faceW*.06f)), Color.rgb(65,65,75))
                oval(nose.first,nose.second+faceW*.06f,faceW*.045f,faceW*.03f,Color.rgb(255,145,175))
                stroke.color=Color.WHITE; stroke.strokeWidth=faceW*.012f
                canvas.drawLine(nose.first-faceW*.05f,nose.second+faceW*.12f,nose.first-faceW*.28f,nose.second+faceW*.09f,stroke)
                canvas.drawLine(nose.first+faceW*.05f,nose.second+faceW*.12f,nose.first+faceW*.28f,nose.second+faceW*.09f,stroke)
            }
            Filter.BUNNY -> {
                oval(cx-faceW*.20f,forehead.second-faceW*.28f,faceW*.11f,faceW*.30f,Color.rgb(245,225,230))
                oval(cx+faceW*.20f,forehead.second-faceW*.28f,faceW*.11f,faceW*.30f,Color.rgb(245,225,230))
                oval(cx-faceW*.20f,forehead.second-faceW*.28f,faceW*.055f,faceW*.22f,Color.rgb(255,140,175))
                oval(cx+faceW*.20f,forehead.second-faceW*.28f,faceW*.055f,faceW*.22f,Color.rgb(255,140,175))
                oval(nose.first,nose.second+faceW*.07f,faceW*.045f,faceW*.035f,Color.rgb(255,125,165))
            }
            Filter.DEVIL -> {
                triangle(listOf(Pair(cx-faceW*.34f,forehead.second),Pair(cx-faceW*.36f,forehead.second-faceW*.32f),Pair(cx-faceW*.08f,forehead.second-faceW*.13f)),Color.rgb(205,35,55))
                triangle(listOf(Pair(cx+faceW*.08f,forehead.second-faceW*.13f),Pair(cx+faceW*.36f,forehead.second-faceW*.32f),Pair(cx+faceW*.34f,forehead.second)),Color.rgb(205,35,55))
                oval(cx-faceW*.18f,forehead.second-faceW*.06f,faceW*.035f,faceW*.045f,Color.RED)
                oval(cx+faceW*.18f,forehead.second-faceW*.06f,faceW*.035f,faceW*.045f,Color.RED)
            }
            Filter.MUSTACHE -> {
                val y=nose.second+faceW*.17f
                fill.color=Color.rgb(55,35,25)
                val path=Path().apply {
                    moveTo(cx,y); cubicTo(cx-faceW*.09f,y-faceW*.14f,cx-faceW*.22f,y-faceW*.13f,cx-faceW*.29f,y+faceW*.02f)
                    cubicTo(cx-faceW*.19f,y+faceW*.02f,cx-faceW*.12f,y+faceW*.12f,cx,y+faceW*.06f)
                    cubicTo(cx+faceW*.12f,y+faceW*.12f,cx+faceW*.19f,y+faceW*.02f,cx+faceW*.29f,y+faceW*.02f)
                    cubicTo(cx+faceW*.22f,y-faceW*.13f,cx+faceW*.09f,y-faceW*.14f,cx,y); close()
                }
                canvas.drawPath(path,fill)
            }
            Filter.BLUSH -> {
                oval(cx-faceW*.28f,nose.second+faceW*.16f,faceW*.10f,faceW*.055f,Color.argb(135,255,75,120))
                oval(cx+faceW*.28f,nose.second+faceW*.16f,faceW*.10f,faceW*.055f,Color.argb(135,255,75,120))
            }
            Filter.ALIEN -> {
                oval(cx,forehead.second+faceW*.02f,faceW*.34f,faceW*.42f,Color.rgb(105,230,115))
                oval(cx-faceW*.15f,forehead.second,faceW*.075f,faceW*.13f,Color.BLACK)
                oval(cx+faceW*.15f,forehead.second,faceW*.075f,faceW*.13f,Color.BLACK)
                stroke.color=Color.rgb(25,100,35); stroke.strokeWidth=faceW*.018f
                canvas.drawArc(cx-faceW*.12f,forehead.second+faceW*.10f,cx+faceW*.12f,forehead.second+faceW*.24f,0f,180f,false,stroke)
            }
            Filter.FLOWER -> {
                val y=forehead.second-faceW*.12f
                for (i in -3..3) {
                    val x=cx+i*faceW*.085f
                    oval(x,y+abs(i)*faceW*.012f,faceW*.06f,faceW*.08f,when(i%3){0->Color.rgb(255,115,170);1->Color.rgb(255,220,70);else->Color.rgb(155,115,255)})
                }
                oval(cx,y,faceW*.045f,faceW*.045f,Color.rgb(255,225,80))
            }
            Filter.STAR -> {
                drawStar(canvas,cx-faceW*.28f,forehead.second-faceW*.18f,faceW*.11f,Color.rgb(255,220,40))
                drawStar(canvas,cx+faceW*.28f,forehead.second-faceW*.20f,faceW*.09f,Color.rgb(255,220,40))
                drawStar(canvas,cx,forehead.second-faceW*.32f,faceW*.07f,Color.WHITE)
            }
            Filter.MASK -> {
                val path=Path().apply {
                    moveTo(cx-faceW*.31f,nose.second-faceW*.04f)
                    quadTo(cx,nose.second+faceW*.02f,cx+faceW*.31f,nose.second-faceW*.04f)
                    lineTo(cx+faceW*.24f,nose.second+faceW*.29f)
                    quadTo(cx,nose.second+faceW*.39f,cx-faceW*.24f,nose.second+faceW*.29f)
                    close()
                }
                fill.color=Color.rgb(50,170,210); canvas.drawPath(path,fill)
                stroke.color=Color.WHITE; stroke.strokeWidth=faceW*.012f
                canvas.drawLine(cx-faceW*.22f,nose.second+faceW*.12f,cx+faceW*.22f,nose.second+faceW*.12f,stroke)
                canvas.drawLine(cx-faceW*.20f,nose.second+faceW*.20f,cx+faceW*.20f,nose.second+faceW*.20f,stroke)
            }
        }
    }

    private fun drawGlasses(canvas: Canvas, le: Pair<Float,Float>, re: Pair<Float,Float>, bridge: Pair<Float,Float>, faceW: Float, color: Int, filled: Boolean) {
        stroke.color=color; stroke.strokeWidth=faceW*.035f
        canvas.drawRoundRect(le.first-faceW*.08f,le.second-faceW*.08f,le.first+faceW*.38f,le.second+faceW*.19f,18f,18f,stroke)
        canvas.drawRoundRect(re.first-faceW*.38f,re.second-faceW*.08f,re.first+faceW*.08f,re.second+faceW*.19f,18f,18f,stroke)
        canvas.drawLine(le.first+faceW*.38f,le.second+faceW*.05f,bridge.first,bridge.second,stroke)
        canvas.drawLine(bridge.first,bridge.second,re.first-faceW*.38f,re.second+faceW*.05f,stroke)
    }

    private fun drawHeart(canvas: Canvas, x: Float, y: Float, s: Float, color: Int) {
        val path=Path().apply { moveTo(x,y+s); cubicTo(x-s*1.8f,y-s*.1f,x-s,y-s,x,y-s*.25f); cubicTo(x+s,y-s,x+s*1.8f,y-s*.1f,x,y+s) }
        fill.color=color; canvas.drawPath(path,fill)
    }
    private fun drawStar(canvas: Canvas, x: Float, y: Float, r: Float, color: Int) {
        val path=Path()
        for (i in 0 until 10) {
            val angle=Math.PI/2 + i*Math.PI/5
            val radius=if (i%2==0) r else r*.43f
            val px=x+(kotlin.math.cos(angle)*radius).toFloat()
            val py=y-(kotlin.math.sin(angle)*radius).toFloat()
            if(i==0) path.moveTo(px,py) else path.lineTo(px,py)
        }
        path.close(); fill.color=color; canvas.drawPath(path,fill)
    }
}
