package com.prateek.offlinefilters

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mediapipe.framework.image.MediaImageBuilder
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.core.ImageProcessingOptions
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarker
import com.google.mediapipe.tasks.vision.facelandmarker.FaceLandmarkerResult
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity() {
    private lateinit var preview: PreviewView
    private lateinit var overlay: FilterOverlayView
    private lateinit var status: TextView
    private lateinit var analyzerExecutor: ExecutorService
    private var landmarker: FaceLandmarker? = null
    private var cameraProvider: ProcessCameraProvider? = null
    private val analyzing = AtomicBoolean(false)

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else status.text = "Camera permission is required to use live filters."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        preview = findViewById(R.id.previewView)
        overlay = findViewById(R.id.filterOverlay)
        status = findViewById(R.id.statusText)
        analyzerExecutor = Executors.newSingleThreadExecutor()
        setupFilterButtons()
        findViewById<Button>(R.id.captureButton).setOnClickListener { captureFilteredPhoto() }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else permissionLauncher.launch(Manifest.permission.CAMERA)
    }

    private fun setupFilterButtons() {
        val row = findViewById<LinearLayout>(R.id.filterButtons)
        val options = listOf(
            "🐶 Dog" to FilterOverlayView.Filter.DOG,
            "🕶 Glasses" to FilterOverlayView.Filter.GLASSES,
            "👑 Crown" to FilterOverlayView.Filter.CROWN,
            "💗 Hearts" to FilterOverlayView.Filter.HEARTS,
            "🐱 Cat" to FilterOverlayView.Filter.CAT,
            "🐰 Bunny" to FilterOverlayView.Filter.BUNNY,
            "😈 Devil" to FilterOverlayView.Filter.DEVIL,
            "🥸 Mustache" to FilterOverlayView.Filter.MUSTACHE,
            "🌸 Blush" to FilterOverlayView.Filter.BLUSH,
            "👽 Alien" to FilterOverlayView.Filter.ALIEN,
            "🌺 Flower" to FilterOverlayView.Filter.FLOWER,
            "⭐ Stars" to FilterOverlayView.Filter.STAR,
            "😷 Mask" to FilterOverlayView.Filter.MASK,
            "Off" to FilterOverlayView.Filter.NONE
        )
        options.forEach { (label, filter) ->
            val b = Button(this).apply {
                text = label; isAllCaps = false; textSize = 12f
                setOnClickListener { overlay.applyFilter(filter) }
            }
            row.addView(b, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginEnd = 8 }
            )
        }
    }

    private fun startCamera() {
        status.text = "Loading on-device face model…"
        try {
            val base = BaseOptions.builder().setModelAssetPath("face_landmarker.task").build()
            val options = FaceLandmarker.FaceLandmarkerOptions.builder()
                .setBaseOptions(base)
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumFaces(1)
                .setMinFaceDetectionConfidence(0.5f)
                .setMinFacePresenceConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .setOutputFaceBlendshapes(false)
                .setOutputFacialTransformationMatrixes(false)
                .setResultListener { result: FaceLandmarkerResult, _ ->
                    val points = result.faceLandmarks().firstOrNull()
                    runOnUiThread {
                        overlay.updateLandmarks(points)
                        status.text = if (points == null) "Move your face into the frame" else "Face tracked • ${overlay.selectedFilterName()} filter"
                    }
                }
                .setErrorListener { error -> runOnUiThread { status.text = "Face tracking error: ${error.message ?: "unknown"}" } }
                .build()
            landmarker = FaceLandmarker.createFromOptions(this, options)
        } catch (e: Exception) {
            status.text = "Model unavailable. Rebuild using the included GitHub workflow."
            return
        }
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            cameraProvider = providerFuture.get()
            val cameraPreview = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setTargetResolution(android.util.Size(480, 640)).build()
            analysis.setAnalyzer(analyzerExecutor) { image -> analyzeFrame(image) }
            try {
                cameraProvider?.unbindAll()
                cameraProvider?.bindToLifecycle(this, CameraSelector.DEFAULT_FRONT_CAMERA, cameraPreview, analysis)
                status.text = "Offline face filters ready"
            } catch (e: Exception) { status.text = "Could not start camera: ${e.message}" }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun analyzeFrame(image: ImageProxy) {
        try {
            val tracker = landmarker ?: return
            val mediaImage = image.image ?: return
            if (!analyzing.compareAndSet(false, true)) return
            val mpImage = MediaImageBuilder(mediaImage).build()
            val imageOptions = ImageProcessingOptions.builder()
                .setRotationDegrees(image.imageInfo.rotationDegrees)
                .build()
            tracker.detectAsync(mpImage, imageOptions, System.nanoTime() / 1_000_000)
        } catch (_: Exception) {
        } finally {
            image.close()
            analyzing.set(false)
        }
    }

    private fun captureFilteredPhoto() {
        val base = preview.bitmap
        if (base == null) { Toast.makeText(this, "Camera is not ready yet", Toast.LENGTH_SHORT).show(); return }
        val output = base.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(output)
        // Render only the live filter overlay into the captured image (not the app controls).
        overlay.draw(canvas)
        val name = "OfflineFilter_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.jpg"
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, name)
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/OfflineFaceFilters")
        }
        try {
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            if (uri == null) throw IllegalStateException("Could not create image")
            contentResolver.openOutputStream(uri)?.use { stream -> output.compress(Bitmap.CompressFormat.JPEG, 94, stream) }
            Toast.makeText(this, "Saved to Pictures/OfflineFaceFilters", Toast.LENGTH_LONG).show()
        } catch (e: Exception) { Toast.makeText(this, "Save failed: ${e.message}", Toast.LENGTH_LONG).show() }
        finally { output.recycle() }
    }

    override fun onDestroy() {
        cameraProvider?.unbindAll()
        landmarker?.close()
        analyzerExecutor.shutdown()
        super.onDestroy()
    }
}
