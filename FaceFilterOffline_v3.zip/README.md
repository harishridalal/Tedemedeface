# Face Filter Offline — expanded starter

Android Kotlin starter with live on-device face tracking and 13 selectable overlays:
Dog, Glasses, Crown, Hearts, Cat, Bunny, Devil, Mustache, Blush, Alien, Flower crown, Stars, and Mask, plus Off.

## Upload/build using a phone
1. Upload the contents of this project ZIP to the root of a GitHub repository and commit.
2. Upload the separate `android-apk.yml` file to `.github/workflows/android-apk.yml`.
3. In GitHub, open Actions → Build Face Filter APK → Run workflow.
4. Download the `FaceFilterOffline-debug-apk` artifact from the completed workflow; extract it to get `app-debug.apk`.

The workflow fetches the MediaPipe model and Gradle dependencies while building. After installation, face detection and overlays run on-device; no app server is used. This is an early starter, not a fully polished Snapchat replacement; camera alignment and device compatibility need real-device testing. Video recording and 3D AR effects are not included yet.
